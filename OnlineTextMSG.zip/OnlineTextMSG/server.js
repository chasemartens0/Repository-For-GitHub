const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const activeUsers = new Set();

const chatHistoryFilePath = path.join(__dirname, 'chat-history.txt');

app.use(express.static(__dirname + '/public'));

function loadChatHistory() {
  if (fs.existsSync(chatHistoryFilePath)) {
    return fs.readFileSync(chatHistoryFilePath, 'utf-8').split('\n').map(line => {
      const [name, text] = line.split(': ');
      return { name, text };
    });
  }
  return [];
}

io.on('connection', (socket) => {
  console.log('A user connected');

  const chatHistory = loadChatHistory();
  socket.emit('loadHistory', chatHistory);

  socket.on('setName', (name, callback) => {
    if (activeUsers.has(name)) {
      callback({ success: false, message: 'Name is already in use. Please choose another.' });
    } else {
      activeUsers.add(name);
      socket.username = name;
      callback({ success: true });
      console.log(`User joined: ${name}`);
    }
  });

  socket.on('message', (data) => {
    const messageLine = `\n${data.name}: ${data.text}`;
    fs.appendFileSync(chatHistoryFilePath, messageLine, 'utf-8');

    io.emit('message', data);
  });

  socket.on('disconnect', () => {
    if (socket.username) {
      activeUsers.delete(socket.username);
      console.log(`User left: ${socket.username}`);
    }
  });
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
